--DESCRIPTION
/*
=> FIRST WE NEED TO CREATE THE EMPLOYEES,REVIEWS,GOALS TABLES USING SQL DDL COMMANDS
=> WE MAKE USE OF FOREIGN KEYS TO ESTABLISH A RELATION BETWEEN TABLES
=> NEXT WE MAKE USE OF DML COMMANDS TO INSERT SAMPLE RECORDS INTO THE TABLES
=> USE PROCEDURES WHICH ARE AVAILABLE IN PL/SQL TO ADD FUNCTIONALITY LIKE INSERT,UPDATE,DELETE 
=>WE HAVE TWO WAYS TO CALL PROCEDURES
 . EXECUTE KEYWORD FOLLOWED BY PROCEDURE NAME
 . CALL THE PROCEDURE NAME BETWEEN EXECUTION PART( BEGIN AND END) 

*/

--Creation of Tables

CREATE TABLE EMPLOYEES(

  employee_id NUMBER PRIMARY KEY,
  first_name VARCHAR2(50),
  last_name varchar2(50),
  email varchar2(100),
  phone_number varchar2(12),
  hire_date DATE,
  department_id NUMBER,
  manager_id NUMBER REFERENCES EMPLOYEES(employee_id)

);

CREATE TABLE REVIEWS(

    review_id NUMBER PRIMARY KEY,
    employee_id NUMBER REFERENCES EMPLOYEES(employee_id),
    review_date DATE,
    reviewer_id NUMBER REFERENCES EMPLOYEES(employee_id),
    comments varchar2(100),
    rating NUMBER

);

CREATE TABLE GOALS(
    
    goal_id NUMBER PRIMARY KEY,
    employee_id NUMBER REFERENCES EMPLOYEES(employee_id),
    goal_description varchar2(255),
    start_date DATE,
    end_date DATE,
    status varchar2(50)

);

--Inserting sample records into the tables created

INSERT INTO Employees VALUES (1, 'Ravi', 'Nalam', 'ravi12@gmail.com', '1234567890', TO_DATE('15-01-2002', 'DD-MM-YYYY'), 10, NULL);
INSERT INTO Employees VALUES (2, 'Sushanth', 'Kalla', 'sushanth44@gmail.com', '0987654321', TO_DATE('19-04-2002', 'DD-MM-YYYY'), 20, 1);
INSERT INTO Employees VALUES (3, 'Jaswanth', 'Mokara', 'jashmk56@gmail.com', '6543217890', TO_DATE('3-09-2003', 'DD-MM-YYYY'), 30, 2);
INSERT INTO Employees VALUES (4, 'Sesh', 'Avatar', 'sesh666@gmail.com', '1357924680', TO_DATE('24-12-2003', 'DD-MM-YYYY'), 40, 3);

select * from EMPLOYEES;

INSERT INTO Reviews VALUES (1, 2, TO_DATE('15-03-2022', 'DD-MM-YYYY'), 4, 'Excellent performance', 5);
INSERT INTO Reviews VALUES (2, 4, TO_DATE('17-09-2020', 'DD-MM-YYYY'), 2, 'Need to do better', 2);
INSERT INTO Reviews VALUES (3, 3, TO_DATE('23-01-2007', 'DD-MM-YYYY'), 1, 'Good', 4);
INSERT INTO Reviews VALUES (4, 1, TO_DATE('9-02-2023', 'DD-MM-YYYY'), 3, 'Avegrage', 3);

select * from REVIEWS;

INSERT INTO Goals VALUES (1, 4, 'Complete project', TO_DATE('2022-01-01', 'YYYY-MM-DD'), TO_DATE('2022-12-31', 'YYYY-MM-DD'), 'Completed');
INSERT INTO Goals VALUES (2, 2, 'Assess the test conditions', TO_DATE('2024-10-04', 'YYYY-MM-DD'), TO_DATE('2025-03-29', 'YYYY-MM-DD'), 'Yet To Be Started');
INSERT INTO Goals VALUES (3, 1, 'Complete project', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'), 'In Progress');

select * from Goals;

--PL/SQL PROCEDURES TO ADD DIFFERENT FUNCTIONALITY
--PROCEDURE FOR MANAGING EMPLOYEE TABLE

 CREATE OR REPLACE PROCEDURE Manage_Employee (
    p_action IN VARCHAR2,
    p_employee_id IN NUMBER,
    p_first_name IN VARCHAR2 DEFAULT NULL,
    p_last_name IN VARCHAR2 DEFAULT NULL,
    p_email IN VARCHAR2 DEFAULT NULL,
    p_phone_number IN VARCHAR2 DEFAULT NULL,
    p_hire_date IN DATE DEFAULT NULL,
    p_department_id IN NUMBER DEFAULT NULL,
    p_manager_id IN NUMBER DEFAULT NULL
  ) AS

    BEGIN

    IF UPPER(p_action) = 'INSERT' THEN
        INSERT INTO Employees VALUES (p_employee_id, p_first_name, p_last_name, p_email, p_phone_number, p_hire_date, p_department_id, p_manager_id);
    
    ELSIF UPPER(p_action) = 'UPDATE' THEN
      BEGIN
        UPDATE Employees
        SET first_name = p_first_name, last_name = p_last_name, email = p_email,
            phone_number = p_phone_number, hire_date = p_hire_date, 
            department_id = p_department_id, manager_id = p_manager_id
        WHERE employee_id = p_employee_id;
        IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('No such record');
        END IF;

      END;

    ELSIF UPPER(p_action) = 'DELETE' THEN
        DELETE FROM Employees WHERE employee_id = p_employee_id;
        IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('No such record');
        END IF;

    ELSE DBMS_OUTPUT.PUT_LINE('ENTER VALID OPERATION TO PERFORM');

    END IF;
     
    END;


BEGIN
     Manage_Employee('INSERT',5,'CHANU','NALAM','chanu@gmail.com','12345',TO_DATE('20-02-1999','DD-MM-YYYY'),40,2);
END;

BEGIN
     Manage_Employee('new',6);
END;


 EXECUTE Manage_Employee('update',2,'Eshwar','Vara','eswar@gmail.com','123',TO_DATE('20-02-1999','DD-MM-YYYY'),40,5);


--PROCEDURE FOR MANAGING REVIEW TABLE
CREATE OR REPLACE PROCEDURE Manage_Review (
    p_action IN VARCHAR2,
    p_review_id IN NUMBER,
    p_employee_id IN NUMBER DEFAULT NULL,
    p_review_date IN DATE DEFAULT NULL,
    p_reviewer_id IN NUMBER DEFAULT NULL,
    p_comments IN VARCHAR2 DEFAULT NULL,
    p_rating IN NUMBER DEFAULT NULL
  ) AS
  BEGIN
    IF UPPER(p_action) = 'INSERT' THEN
        INSERT INTO Reviews  VALUES (p_review_id, p_employee_id, p_review_date, p_reviewer_id, p_comments, p_rating);
    ELSIF UPPER(p_action) = 'UPDATE' THEN
        UPDATE Reviews
        SET employee_id = p_employee_id, review_date = p_review_date, 
            reviewer_id = p_reviewer_id, comments = p_comments, rating = p_rating
        WHERE review_id = p_review_id;
        IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('No such record');
        END IF;

    ELSIF UPPER(p_action) = 'DELETE' THEN
        DELETE FROM Reviews WHERE review_id = p_review_id;
        IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('No such record');
        END IF;
    
    ELSE DBMS_OUTPUT.PUT_LINE('ENTER VALID OPERATION TO PERFORM');

    END IF;
  END;

BEGIN
    Manage_Review('INSERT', 5, 2, TO_DATE('2023-06-15', 'YYYY-MM-DD'), 1, 'Good performance', 4);
END;

  EXECUTE Manage_Review('update',2,1);

  EXECUTE Manage_Review('delete',5);

--PROCEDURE FOR MANAGING GOAL TABLE

CREATE OR REPLACE PROCEDURE Manage_Goal (
    p_action IN VARCHAR2,
    p_goal_id IN NUMBER,
    p_employee_id IN NUMBER DEFAULT NULL,
    p_goal_description IN VARCHAR2 DEFAULT NULL,
    p_start_date IN DATE DEFAULT NULL,
    p_end_date IN DATE DEFAULT NULL,
    p_status IN VARCHAR2 DEFAULT NULL
  ) AS
  BEGIN
    IF UPPER(p_action) = 'INSERT' THEN
        INSERT INTO Goals (GOAL_ID, EMPLOYEE_ID, GOAL_DESCRIPTION, START_DATE, END_DATE, STATUS)
        VALUES (p_goal_id, p_employee_id, p_goal_description, p_start_date, p_end_date, p_status);
    ELSIF UPPER(p_action) = 'UPDATE' THEN
        UPDATE Goals
        SET EMPLOYEE_ID = p_employee_id, GOAL_DESCRIPTION = p_goal_description, 
            START_DATE = p_start_date, END_DATE = p_end_date, STATUS = p_status
        WHERE GOAL_ID = p_goal_id;
        IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('No such record');
        END IF;


    ELSIF UPPER(p_action) = 'DELETE' THEN
        DELETE FROM Goals WHERE GOAL_ID = p_goal_id;
        IF SQL%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('No such record');
        END IF;
    
    ELSE DBMS_OUTPUT.PUT_LINE('ENTER VALID OPERATION TO PERFORM');

    END IF;
  END;

BEGIN
   
    Manage_Goal('INSERT', 6, 2, 'Achieve the target', TO_DATE('2023-01-01', 'YYYY-MM-DD'), TO_DATE('2023-12-31', 'YYYY-MM-DD'), 'In Progress');
END;

 EXECUTE  Manage_Goal('update',6,3,'Needs promotion',TO_DATE('2023-01-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'), 'In Progress');







        